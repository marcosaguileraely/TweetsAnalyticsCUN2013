
package com.tweetsdb;



/**
 *  Query names for service "tweetsdb"
 *  11/30/2013 23:12:11
 * 
 */
public class TweetsdbConstants {

    public final static String getUserByIdQueryName = "getUserById";

}
