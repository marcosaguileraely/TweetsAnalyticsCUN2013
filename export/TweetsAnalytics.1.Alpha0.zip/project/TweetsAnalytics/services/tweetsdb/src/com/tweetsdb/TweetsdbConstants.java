
package com.tweetsdb;



/**
 *  Query names for service "tweetsdb"
 *  12/01/2013 00:08:39
 * 
 */
public class TweetsdbConstants {

    public final static String getUserByIdQueryName = "getUserById";

}
