
package com.tweetsdb.data;



/**
 *  tweetsdb.Security
 *  12/01/2013 13:32:25
 * 
 */
public class Security {

    private Integer idsecurity;
    private String nameuser;
    private String password;

    public Integer getIdsecurity() {
        return idsecurity;
    }

    public void setIdsecurity(Integer idsecurity) {
        this.idsecurity = idsecurity;
    }

    public String getNameuser() {
        return nameuser;
    }

    public void setNameuser(String nameuser) {
        this.nameuser = nameuser;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
