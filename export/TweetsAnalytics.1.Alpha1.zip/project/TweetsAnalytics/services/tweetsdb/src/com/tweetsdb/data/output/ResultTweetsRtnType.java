
package com.tweetsdb.data.output;



/**
 * Generated for query "resultTweets" on 12/01/2013 14:18:41
 * 
 */
public class ResultTweetsRtnType {

    private Integer id;
    private String fullname;
    private String user;
    private String text;
    private Integer polar;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Integer getPolar() {
        return polar;
    }

    public void setPolar(Integer polar) {
        this.polar = polar;
    }

}
