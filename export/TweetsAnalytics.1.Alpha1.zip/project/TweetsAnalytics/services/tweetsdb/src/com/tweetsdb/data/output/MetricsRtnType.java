
package com.tweetsdb.data.output;



/**
 * Generated for query "metrics" on 12/01/2013 14:18:41
 * 
 */
public class MetricsRtnType {

    private String language;
    private String name;
    private Integer polarity;
    private Long total_polar;

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPolarity() {
        return polarity;
    }

    public void setPolarity(Integer polarity) {
        this.polarity = polarity;
    }

    public Long getTotal_polar() {
        return total_polar;
    }

    public void setTotal_polar(Long total_polar) {
        this.total_polar = total_polar;
    }

}
