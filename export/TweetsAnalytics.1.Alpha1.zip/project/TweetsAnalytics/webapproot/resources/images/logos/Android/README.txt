Launch Icons:
36x36: ldpi display
48x48: mdpi display
72x72: hdpi display
96x96: xhdpi display

Splash Screens
320x480:  ldpi display
460x960:  mdpi display
768x1024: hdpi display
1024x1364:xhdpi display
